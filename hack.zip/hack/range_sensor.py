import RPi.GPIO as GPIO
import time
import pyrebase

config = {
	"apiKey": "AIzaSyBa9DZxWSnrVrnluj6NX5dTRjYz311a4m4",
  "authDomain": "alpha-f639b.firebaseapp.com",
  "databaseURL": "https://alpha-f639b.firebaseio.com",
  "storageBucket": "alpha-f639b.appspot.com",
    "serviceAccount": "alpha-f639b-firebase-adminsdk-nwudc-70b194c700.json"
}

firebase = pyrebase.initialize_app(config)

db = firebase.database()

GPIO.setmode(GPIO.BCM)

TRIG = 23 
ECHO = 24

print "Distance Measurement In Progress"

GPIO.setup(TRIG,GPIO.OUT)
GPIO.setup(ECHO,GPIO.IN)

GPIO.output(TRIG, False)
print "Waiting For Sensor To Settle"
time.sleep(2)

bandera = 0

while 1:
    GPIO.output(TRIG, True)
    time.sleep(0.00001)
    GPIO.output(TRIG, False)

    while GPIO.input(ECHO)==0:
      pulse_start = time.time()

    while GPIO.input(ECHO)==1:
      pulse_end = time.time()

    pulse_duration = pulse_end - pulse_start

    distance = pulse_duration * 17150

    distance = round(distance, 2)

    if distance < 100 and bandera == 0:
        data = { "llegada":"1" }
        db.child('prueba').child('Camion').set(data)
        bandera = 1
    elif distance > 100 and bandera == 1:
        db.child('prueba').child('Camion').update({"llegada":"0"})
        bandera = 0

    print "Distance:",distance,"cm"
    time.sleep(0.1)
GPIO.cleanup()
